package com.lenovo.lenovoweathertheme;

public final class R
{
  public static final class attr
  {
  }

  public static final class drawable
  {
    public static final int ic_launcher = 2130837504;
    public static final int lenweather_widget_bg = 2130837505;
    public static final int lenweather_widget_bg_cloudy = 2130837506;
    public static final int lenweather_widget_bg_default = 2130837507;
    public static final int lenweather_widget_bg_foggy = 2130837508;
    public static final int lenweather_widget_bg_rain = 2130837509;
    public static final int lenweather_widget_bg_sand = 2130837510;
    public static final int lenweather_widget_bg_smoke = 2130837511;
    public static final int lenweather_widget_bg_snow = 2130837512;
    public static final int lenweather_widget_bg_sunny = 2130837513;
    public static final int lenweather_widget_bg_thunder = 2130837514;
    public static final int lenweather_widget_bg_wind = 2130837515;
    public static final int lenweather_widget_colon = 2130837516;
    public static final int lenweather_widget_icon_big_rain = 2130837517;
    public static final int lenweather_widget_icon_big_snow = 2130837518;
    public static final int lenweather_widget_icon_cloudy = 2130837519;
    public static final int lenweather_widget_icon_cold = 2130837520;
    public static final int lenweather_widget_icon_fog = 2130837521;
    public static final int lenweather_widget_icon_free_rain = 2130837522;
    public static final int lenweather_widget_icon_haze = 2130837523;
    public static final int lenweather_widget_icon_hot = 2130837524;
    public static final int lenweather_widget_icon_ice_rain = 2130837525;
    public static final int lenweather_widget_icon_mid_cloud = 2130837526;
    public static final int lenweather_widget_icon_mid_rain = 2130837527;
    public static final int lenweather_widget_icon_mid_snow = 2130837528;
    public static final int lenweather_widget_icon_most_cloudy = 2130837529;
    public static final int lenweather_widget_icon_rain_snow = 2130837530;
    public static final int lenweather_widget_icon_small_rain = 2130837531;
    public static final int lenweather_widget_icon_small_snow = 2130837532;
    public static final int lenweather_widget_icon_smoke = 2130837533;
    public static final int lenweather_widget_icon_sunny = 2130837534;
    public static final int lenweather_widget_icon_sunny_cloudy = 2130837535;
    public static final int lenweather_widget_icon_thunder_rain = 2130837536;
    public static final int lenweather_widget_icon_wind = 2130837537;
    public static final int lenweather_widget_num_0 = 2130837538;
    public static final int lenweather_widget_num_1 = 2130837539;
    public static final int lenweather_widget_num_2 = 2130837540;
    public static final int lenweather_widget_num_3 = 2130837541;
    public static final int lenweather_widget_num_4 = 2130837542;
    public static final int lenweather_widget_num_5 = 2130837543;
    public static final int lenweather_widget_num_6 = 2130837544;
    public static final int lenweather_widget_num_7 = 2130837545;
    public static final int lenweather_widget_num_8 = 2130837546;
    public static final int lenweather_widget_num_9 = 2130837547;
    public static final int lenweather_widget_time_am = 2130837548;
    public static final int lenweather_widget_time_pm = 2130837549;
  }

  public static final class id
  {
    public static final int temperature_max = 2131099664;
    public static final int temperature_min = 2131099663;
    public static final int temperature_unit = 2131099665;
    public static final int weather_img = 2131099659;
    public static final int widgetAPMImage = 2131099655;
    public static final int widgetCityNameText = 2131099661;
    public static final int widgetClock = 2131099649;
    public static final int widgetColonImage = 2131099652;
    public static final int widgetDateText = 2131099657;
    public static final int widgetHour01Image = 2131099650;
    public static final int widgetHour02Image = 2131099651;
    public static final int widgetMinute01Image = 2131099653;
    public static final int widgetMinute02Image = 2131099654;
    public static final int widgetTempLayout = 2131099662;
    public static final int widgetTimeLayout = 2131099648;
    public static final int widgetWeatherLayout = 2131099658;
    public static final int widgetWeatherText = 2131099666;
    public static final int widgetWeekText = 2131099656;
    public static final int widget_bg_2 = 2131099660;
  }

  public static final class layout
  {
    public static final int weather_widget_provider = 2130903040;
  }

  public static final class string
  {
    public static final int app_name = 2130968576;
  }

  public static final class style
  {
    public static final int AppBaseTheme = 2131034112;
    public static final int AppTheme = 2131034113;
  }
}

/* Location:           D:\Apk_Decomplier_ICS_1.0.2\projects\简而未减\简而未减_dex2jar.jar
 * Qualified Name:     com.lenovo.lenovoweathertheme.R
 * JD-Core Version:    0.6.0
 */